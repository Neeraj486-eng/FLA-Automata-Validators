# Finite Automata for Real-Time Validation

**Course:** Formal Languages and Automata (FLA)  
**Project:** Designing Automata for Real-Time Applications  
**Student:** K Neeraj (RA2411026050023)

This project demonstrates how Deterministic Finite Automata (DFAs) can be used to validate common input formats. It implements three independent validators: password structure verification, simplified e-mail syntax validation, and four-digit ATM PIN format validation.

| # | Application | Automaton idea | Acceptance condition |
|---|---|---|---|
| 1 | Password validation | DFA state tracks length and required character classes | 8–16 allowed characters, including uppercase, lowercase, digit, and special character |
| 2 | E-mail validation | DFA-style state transitions for local part, `@`, domain, and suffix | Matches the simplified e-mail grammar described below |
| 3 | ATM PIN validation | DFA counts the number of digits read | Exactly four digits |

The implementation uses Python's standard library and does not require external packages.

## Run it

```bash
# Clone the repository
git clone https://github.com/Neeraj486-eng/FLA-Automata-Validators.git
cd FLA-Automata-Validators

# Run the validators
python main.py
```

Choose an option from the menu, enter the required input, and the program displays `ACCEPTED` or `REJECTED`.

## 1. Password structure verification

**Policy:** The password must contain 8–16 characters and include at least one uppercase letter, one lowercase letter, one digit, and one permitted special character. Spaces and unsupported characters are rejected.

- Character classes: `U` = uppercase, `L` = lowercase, `D` = digit, `S` = permitted special character.
- Permitted special characters: `!@#$%^&*()-_=+[]{};:,.?/`
- The DFA tracks the input length and which required character classes have appeared.
- An input is accepted only when the length is within the required range and all four character-class conditions are satisfied.

**Example accepted input:** `Abcdef1!`  
**Example rejected input:** `abcdef1!` (no uppercase letter)

[View password DFA design](diagrams/password_dfa.md)

## 2. Simplified e-mail syntax validation

The validator checks a deliberately simplified e-mail format. It is intended for demonstrating finite-state validation and is not a complete implementation of the e-mail standards.

```text
local  = alphanumeric (alphanumeric | . | _ | -)* alphanumeric
email  = local @ host . suffix
host   = alphanumeric+
suffix = letter{2,}
```

Additional restrictions in the implementation:

- Exactly one `@` symbol is required.
- The local part must begin and end with an alphanumeric character.
- Separators `.`, `_`, and `-` cannot be consecutive.
- The domain contains one alphanumeric host label, one dot, and a suffix of at least two letters.

**Example accepted input:** `john.doe@mail.net`  
**Example rejected input:** `john..doe@mail.net` (consecutive separators)

[View e-mail DFA design](diagrams/email_dfa.md)

## 3. Four-digit ATM PIN validation

**Policy:** The PIN must contain exactly four digits (`0`–`9`). Leading zeroes are valid.

- The automaton starts at `q0` and advances one state for each digit read.
- `q4` is the accepting state, reached after exactly four digits.
- Any non-digit or any additional digit causes rejection.

**Example accepted input:** `0042`  
**Example rejected input:** `12345` (more than four digits)

[View PIN DFA design](diagrams/pin_dfa.md)

## Test cases

The project includes sample accepted and rejected inputs for all three validators.

| Validator | Accepted examples | Rejected examples |
|---|---|---|
| Password | `Abcdef1!`, `Hello123@`, `A1!bcdef` | `abcdef1!`, `Abcdef12`, `Ab1!` |
| E-mail | `alex@example.com`, `john.doe@mail.net`, `user_name@host.in` | `@example.com`, `alexexample.com`, `alex..doe@example.com` |
| PIN | `1234`, `0000`, `0042` | `123`, `12345`, `12a4` |

See [test_cases/test_cases.md](test_cases/test_cases.md) for the full test list.

## Syntax validation vs. real-world verification

A finite automaton checks whether an input string follows a defined pattern. It does not establish whether the input is valid in a wider real-world sense.

- **Password:** checks structure only; it does not authenticate a user or check password strength against external breach data.
- **E-mail:** checks the simplified syntax only; it does not verify that the domain or mailbox exists.
- **ATM PIN:** checks that the input has four digits only; it does not verify a PIN against a bank account or perform authentication.

These limitations are intentional because the project focuses on formal language recognition using finite automata.

## Project structure

```text
FLA-Automata-Validators/
├── main.py
├── README.md
├── requirements.txt
├── diagrams/
│   ├── password_dfa.md
│   ├── email_dfa.md
│   └── pin_dfa.md
└── test_cases/
    └── test_cases.md
```

| File | Description |
|---|---|
| `main.py` | Implements the three input validators and the command-line menu |
| `diagrams/` | Contains the DFA design descriptions and diagrams in Mermaid format |
| `test_cases/` | Contains accepted and rejected sample inputs |
| `requirements.txt` | Documents dependencies (Python standard library only) |

## Conclusion

This project applies the concepts of finite automata to familiar input-validation tasks. By defining states, transitions, and accepting conditions, the validators demonstrate how regular languages can represent structured input rules. The project also highlights the difference between checking a string's format and verifying its real-world meaning.
